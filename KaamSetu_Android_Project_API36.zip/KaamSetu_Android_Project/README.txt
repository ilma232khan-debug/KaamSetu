KaamSetu Android Project
========================

This is the Android-ready KaamSetu app project.

Updated for Google Play's Android 16 / API 36 target requirement.
The app is designed to work offline and stores customer/task/payment data locally on the device.

To make an APK on a computer:
1. Install Android Studio.
2. Open this KaamSetu folder.
3. Let Android Studio install/sync the required Android SDK and Gradle components.
4. Build > Build APK(s).
5. The APK will be created in app/build/outputs/apk/

For sharing outside Play Store, the APK can be sent to users directly (they may need to allow installation from that source).

Note: This package is project source, not a precompiled APK. This environment does not have the Android SDK/Gradle toolchain needed to compile the APK here.
